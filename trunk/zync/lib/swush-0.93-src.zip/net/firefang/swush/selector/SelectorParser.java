// $ANTLR 3.1.3 Mar 17, 2009 19:23:44 src/Selector.g 2009-08-03 23:54:14

/**
 * Automatically generated code, do not edit!
 * To modify, make changes to APP.g (ANTLR file).
 */
package net.firefang.swush.selector;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;


import org.antlr.runtime.tree.*;

public class SelectorParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "WORD", "WS", "'.'"
    };
    public static final int WORD=4;
    public static final int WS=5;
    public static final int EOF=-1;
    public static final int T__6=6;

    // delegates
    // delegators


        public SelectorParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public SelectorParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return SelectorParser.tokenNames; }
    public String getGrammarFileName() { return "src/Selector.g"; }


        public static void main(String[] args) throws Exception {
            SelectorLexer lex = new SelectorLexer(new ANTLRFileStream(args[0]));
            CommonTokenStream tokens = new CommonTokenStream(lex);

            SelectorParser parser = new SelectorParser(tokens);
            

            try {
                parser.selector();
            } catch (RecognitionException e)  {
                e.printStackTrace();
            }
        }


    public static class selector_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "selector"
    // src/Selector.g:40:1: selector : ( list EOF | EOF );
    public final SelectorParser.selector_return selector() throws RecognitionException {
        SelectorParser.selector_return retval = new SelectorParser.selector_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token EOF2=null;
        Token EOF3=null;
        SelectorParser.list_return list1 = null;


        Object EOF2_tree=null;
        Object EOF3_tree=null;

        try {
            // src/Selector.g:40:9: ( list EOF | EOF )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==WORD) ) {
                alt1=1;
            }
            else if ( (LA1_0==EOF) ) {
                alt1=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // src/Selector.g:40:11: list EOF
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_list_in_selector42);
                    list1=list();

                    state._fsp--;

                    adaptor.addChild(root_0, list1.getTree());
                    EOF2=(Token)match(input,EOF,FOLLOW_EOF_in_selector44); 

                    }
                    break;
                case 2 :
                    // src/Selector.g:40:23: EOF
                    {
                    root_0 = (Object)adaptor.nil();

                    EOF3=(Token)match(input,EOF,FOLLOW_EOF_in_selector49); 

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "selector"

    public static class list_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "list"
    // src/Selector.g:41:1: list : WORD ( '.' list )? ;
    public final SelectorParser.list_return list() throws RecognitionException {
        SelectorParser.list_return retval = new SelectorParser.list_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token WORD4=null;
        Token char_literal5=null;
        SelectorParser.list_return list6 = null;


        Object WORD4_tree=null;
        Object char_literal5_tree=null;

        try {
            // src/Selector.g:41:6: ( WORD ( '.' list )? )
            // src/Selector.g:41:8: WORD ( '.' list )?
            {
            root_0 = (Object)adaptor.nil();

            WORD4=(Token)match(input,WORD,FOLLOW_WORD_in_list57); 
            WORD4_tree = (Object)adaptor.create(WORD4);
            adaptor.addChild(root_0, WORD4_tree);

            // src/Selector.g:41:13: ( '.' list )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==6) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // src/Selector.g:41:14: '.' list
                    {
                    char_literal5=(Token)match(input,6,FOLLOW_6_in_list60); 
                    pushFollow(FOLLOW_list_in_list63);
                    list6=list();

                    state._fsp--;

                    adaptor.addChild(root_0, list6.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "list"

    // Delegated rules


 

    public static final BitSet FOLLOW_list_in_selector42 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_selector44 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EOF_in_selector49 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_WORD_in_list57 = new BitSet(new long[]{0x0000000000000042L});
    public static final BitSet FOLLOW_6_in_list60 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_list_in_list63 = new BitSet(new long[]{0x0000000000000002L});

}