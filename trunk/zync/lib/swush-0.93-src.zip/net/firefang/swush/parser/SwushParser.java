// $ANTLR 3.1.3 Mar 17, 2009 19:23:44 src/Swush.g 2009-08-03 23:54:15

/**
 * Automatically generated code, do not edit!
 * To modify, make changes to Swush.g (ANTLR file).
 */
package net.firefang.swush.parser;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;


import org.antlr.runtime.tree.*;

public class SwushParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "QSTRING", "WORD", "SINGLELINE_COMMENT", "MULTILINE_COMMENT", "COMMENT", "WS", "'@swush 1.0'", "'{'", "'}'", "':'"
    };
    public static final int WORD=5;
    public static final int MULTILINE_COMMENT=7;
    public static final int WS=9;
    public static final int T__12=12;
    public static final int SINGLELINE_COMMENT=6;
    public static final int T__11=11;
    public static final int T__13=13;
    public static final int T__10=10;
    public static final int QSTRING=4;
    public static final int COMMENT=8;
    public static final int EOF=-1;

    // delegates
    // delegators


        public SwushParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public SwushParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return SwushParser.tokenNames; }
    public String getGrammarFileName() { return "src/Swush.g"; }


        public static void main(String[] args) throws Exception {
            SwushLexer lex = new SwushLexer(new ANTLRFileStream(args[0]));
            CommonTokenStream tokens = new CommonTokenStream(lex);

            SwushParser parser = new SwushParser(tokens);
            

            try {
                parser.swush_file();
            } catch (RecognitionException e)  {
                e.printStackTrace();
            }
        }


    public static class swush_file_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "swush_file"
    // src/Swush.g:41:1: swush_file : ( swush )* EOF ;
    public final SwushParser.swush_file_return swush_file() throws RecognitionException {
        SwushParser.swush_file_return retval = new SwushParser.swush_file_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token EOF2=null;
        SwushParser.swush_return swush1 = null;


        Object EOF2_tree=null;

        try {
            // src/Swush.g:41:12: ( ( swush )* EOF )
            // src/Swush.g:42:3: ( swush )* EOF
            {
            root_0 = (Object)adaptor.nil();

            // src/Swush.g:42:3: ( swush )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>=QSTRING && LA1_0<=WORD)) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // src/Swush.g:42:3: swush
            	    {
            	    pushFollow(FOLLOW_swush_in_swush_file53);
            	    swush1=swush();

            	    state._fsp--;

            	    adaptor.addChild(root_0, swush1.getTree());

            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

            EOF2=(Token)match(input,EOF,FOLLOW_EOF_in_swush_file56); 

            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "swush_file"

    public static class header_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "header"
    // src/Swush.g:44:1: header : '@swush 1.0' ( string )? ;
    public final SwushParser.header_return header() throws RecognitionException {
        SwushParser.header_return retval = new SwushParser.header_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token string_literal3=null;
        SwushParser.string_return string4 = null;


        Object string_literal3_tree=null;

        try {
            // src/Swush.g:44:8: ( '@swush 1.0' ( string )? )
            // src/Swush.g:44:10: '@swush 1.0' ( string )?
            {
            root_0 = (Object)adaptor.nil();

            string_literal3=(Token)match(input,10,FOLLOW_10_in_header67); 
            string_literal3_tree = (Object)adaptor.create(string_literal3);
            adaptor.addChild(root_0, string_literal3_tree);

            // src/Swush.g:44:23: ( string )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( ((LA2_0>=QSTRING && LA2_0<=WORD)) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // src/Swush.g:44:23: string
                    {
                    pushFollow(FOLLOW_string_in_header69);
                    string4=string();

                    state._fsp--;

                    adaptor.addChild(root_0, string4.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "header"

    public static class swush_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "swush"
    // src/Swush.g:47:1: swush : string ( '{' ( swush )* '}' | ':' string )? ;
    public final SwushParser.swush_return swush() throws RecognitionException {
        SwushParser.swush_return retval = new SwushParser.swush_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token char_literal6=null;
        Token char_literal8=null;
        Token char_literal9=null;
        SwushParser.string_return string5 = null;

        SwushParser.swush_return swush7 = null;

        SwushParser.string_return string10 = null;


        Object char_literal6_tree=null;
        Object char_literal8_tree=null;
        Object char_literal9_tree=null;

        try {
            // src/Swush.g:47:6: ( string ( '{' ( swush )* '}' | ':' string )? )
            // src/Swush.g:48:3: string ( '{' ( swush )* '}' | ':' string )?
            {
            root_0 = (Object)adaptor.nil();

            pushFollow(FOLLOW_string_in_swush81);
            string5=string();

            state._fsp--;

            root_0 = (Object)adaptor.becomeRoot(string5.getTree(), root_0);
            // src/Swush.g:48:11: ( '{' ( swush )* '}' | ':' string )?
            int alt4=3;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==11) ) {
                alt4=1;
            }
            else if ( (LA4_0==13) ) {
                alt4=2;
            }
            switch (alt4) {
                case 1 :
                    // src/Swush.g:48:12: '{' ( swush )* '}'
                    {
                    char_literal6=(Token)match(input,11,FOLLOW_11_in_swush85); 
                    char_literal6_tree = (Object)adaptor.create(char_literal6);
                    adaptor.addChild(root_0, char_literal6_tree);

                    // src/Swush.g:48:16: ( swush )*
                    loop3:
                    do {
                        int alt3=2;
                        int LA3_0 = input.LA(1);

                        if ( ((LA3_0>=QSTRING && LA3_0<=WORD)) ) {
                            alt3=1;
                        }


                        switch (alt3) {
                    	case 1 :
                    	    // src/Swush.g:48:16: swush
                    	    {
                    	    pushFollow(FOLLOW_swush_in_swush87);
                    	    swush7=swush();

                    	    state._fsp--;

                    	    adaptor.addChild(root_0, swush7.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop3;
                        }
                    } while (true);

                    char_literal8=(Token)match(input,12,FOLLOW_12_in_swush90); 
                    char_literal8_tree = (Object)adaptor.create(char_literal8);
                    adaptor.addChild(root_0, char_literal8_tree);


                    }
                    break;
                case 2 :
                    // src/Swush.g:48:29: ':' string
                    {
                    char_literal9=(Token)match(input,13,FOLLOW_13_in_swush94); 
                    char_literal9_tree = (Object)adaptor.create(char_literal9);
                    adaptor.addChild(root_0, char_literal9_tree);

                    pushFollow(FOLLOW_string_in_swush96);
                    string10=string();

                    state._fsp--;

                    adaptor.addChild(root_0, string10.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "swush"

    public static class string_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "string"
    // src/Swush.g:50:1: string : ( QSTRING | WORD );
    public final SwushParser.string_return string() throws RecognitionException {
        SwushParser.string_return retval = new SwushParser.string_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token set11=null;

        Object set11_tree=null;

        try {
            // src/Swush.g:50:8: ( QSTRING | WORD )
            // src/Swush.g:
            {
            root_0 = (Object)adaptor.nil();

            set11=(Token)input.LT(1);
            if ( (input.LA(1)>=QSTRING && input.LA(1)<=WORD) ) {
                input.consume();
                adaptor.addChild(root_0, (Object)adaptor.create(set11));
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "string"

    // Delegated rules


 

    public static final BitSet FOLLOW_swush_in_swush_file53 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_EOF_in_swush_file56 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_10_in_header67 = new BitSet(new long[]{0x0000000000000032L});
    public static final BitSet FOLLOW_string_in_header69 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_string_in_swush81 = new BitSet(new long[]{0x0000000000002802L});
    public static final BitSet FOLLOW_11_in_swush85 = new BitSet(new long[]{0x0000000000001030L});
    public static final BitSet FOLLOW_swush_in_swush87 = new BitSet(new long[]{0x0000000000001030L});
    public static final BitSet FOLLOW_12_in_swush90 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_13_in_swush94 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_string_in_swush96 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_string0 = new BitSet(new long[]{0x0000000000000002L});

}