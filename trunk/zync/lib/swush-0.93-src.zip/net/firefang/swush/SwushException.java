package net.firefang.swush;

public class SwushException extends RuntimeException
{
	public SwushException()
	{
	}

	public SwushException(String message)
	{
		super(message);
	}

	public SwushException(Throwable cause)
	{
		super(cause);
	}

	public SwushException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
